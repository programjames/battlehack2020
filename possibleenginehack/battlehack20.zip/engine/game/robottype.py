from enum import Enum


class RobotType(Enum):
    OVERLORD = 0
    PAWN = 1
