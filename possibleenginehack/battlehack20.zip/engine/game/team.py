from enum import Enum


class Team(Enum):
    WHITE = 0
    BLACK = 1
